# MYRA AI — Stage 2 (एरर-फिक्स्ड वर्ज़न)

## 1. क्या गलत था और क्या ठीक किया

**पक्का कंपाइल एरर (यही बिल्ड फेल करता था):**
`comms/CommsController.kt` की लाइन 16 पर `val phone = ContactsContract.CommonDataKinds.Phone` लिखा था। Kotlin में Java क्लास को वैरिएबल की तरह नहीं रखा जा सकता ("Classifier ... does not have a companion object")।
अब `Phone` को सीधे इम्पोर्ट करके इस्तेमाल किया गया है और Cursor `try/finally` से बंद होता है।

**एहतियातन और सीधे किए गए हिस्से** (ये एरर होने की गारंटी नहीं थे, पर कंपाइलर-नियमों पर टिके थे):
- `getSystemService(X::class.java)` पर साफ़ cast, ताकि SDK चाहे `T` दे या `T?`, कोड कंपाइल हो।
- `BossAuth`: `const val ... or ...` की जगह सादा `val`।
- `CommandRouter`: स्ट्रिंग में `"$"` की जगह `"\$"`, `private` की जगह `internal` sealed class, और स्ट्रिंग-टेम्पलेट के भीतर की स्ट्रिंग हटाई।
- `OrbView`: animator को `init{}` में सेट किया, ताकि `apply{}` में नाम-मिलान का भ्रम न हो।
- Gradle: `lint { abortOnError = false }`, ताकि lint की चेतावनी बिल्ड न रोके।

**GitHub Actions के लिए जोड़ा गया:** `.github/workflows/android.yml` (JDK 17, Android SDK, Gradle 8.9 अपने-आप)। Gradle wrapper की ज़रूरत नहीं है।

## 2. GitHub पर बिल्ड कैसे करें
1. ZIP को extract करें। अंदर `MYRA-AI` फ़ोल्डर मिलेगा।
2. उस फ़ोल्डर के **अंदर की** चीज़ें (`app`, `settings.gradle.kts`, `gradle.properties`, `.github` आदि) अपने रिपॉज़िटरी के रूट में अपलोड करें। `settings.gradle.kts` रिपॉज़िटरी में सबसे ऊपर दिखनी चाहिए।
3. `.github` छिपा फ़ोल्डर है और अपलोड में छूट सकता है। छूटे तो GitHub में **Add file → Create new file** खोलकर नाम `.github/workflows/android.yml` लिखें और इस ZIP वाली फ़ाइल की पूरी सामग्री पेस्ट करें।
4. **Actions** टैब → **Build MYRA APK** → **Run workflow**।
5. हरा ✓ आने पर उस run को खोलें → नीचे **Artifacts** में `myra-debug-apk` डाउनलोड करें → APK फ़ोन में इंस्टॉल करें (अज्ञात स्रोत की अनुमति देनी होगी)।

## 3. अगर फिर भी बिल्ड फेल हो
मैं यहाँ कंपाइलर नहीं चला सका, इसलिए असली लॉग ही अंतिम सबूत है।
1. Actions → फेल हुआ run → **Build debug APK** स्टेप खोलें।
2. वहाँ की `e: file:///...` से शुरू होने वाली लाल लाइनें कॉपी करें (फ़ाइल का नाम और लाइन नंबर सहित)।
3. वो मुझे भेजें, मैं उसी लाइन को ठीक कर दूँगा।

| लॉग में यह दिखे | मतलब |
|---|---|
| `settings.gradle.kts not found` | फ़ाइलें रूट में नहीं गईं, पिछला चरण 2 देखें |
| `SDK location not found` | `android-actions/setup-android` स्टेप हटा या फेल हो गया है, वर्कफ़्लो फिर से डालें |
| `Unsupported class file major version` | Java 17 सेट नहीं है, वर्कफ़्लो की `java-version: 17` वाली लाइन देखें |
| `e: ... Unresolved reference` / `Type mismatch` | असली Kotlin एरर, लाइन मुझे भेजें |

## 4. Android Studio से बिल्ड (वैकल्पिक)
फ़ोल्डर खोलें → Sync → Run। पहली बार Gradle wrapper अपने-आप बन जाता है।

## 5. पहली बार चलाने पर
- बोलने के लिए ऑर्ब पर टैप करें और माइक की अनुमति दें।
- "lock kar do" बोलें, फिर Device Admin में Activate करें।
- "screen padho" बोलें, फिर Accessibility में *MYRA Screen Automation* चालू करें। Android 13+ पर साइडलोड किए ऐप के लिए पहले App info → ⋮ → *Allow restricted settings*।
- कॉल, SMS और Contacts की अनुमति पहली बार इस्तेमाल पर माँगी जाती है।
- आज़माने के लिए: "torch on karo", "battery kitni hai", "7 baje ka alarm", "Rahul ko whatsapp karo ki main late hoon".

## 6. ईमानदार नोट्स
- "100% कंपाइल" का वादा मैं बिना कंपाइलर चलाए नहीं कर सकता। मैंने हर Kotlin फ़ाइल हाथ से पढ़ी, इम्पोर्ट, रिसोर्स और स्क्रिप्ट से क्रॉस-चेक किए, और पक्का एरर ठीक किया। पर असली पुष्टि आपके GitHub बिल्ड से ही मिलेगी।
- ऐप का डिबग APK बनता है। Play Store के लिए साइनिंग और रिलीज़ बिल्ड अलग से चाहिए।
