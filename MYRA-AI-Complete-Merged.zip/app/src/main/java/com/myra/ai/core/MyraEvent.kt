package com.myra.ai.core

import com.myra.ai.ui.OrbView

enum class Kind { BOOT, SYS, ERR, YOU, MYRA, CODE }

/** Everything the UI needs to render, published by [MyraEngine]. */
sealed interface MyraEvent {
    data class Line(val id: Long, val kind: Kind, val tag: String, val text: String) : MyraEvent
    data class Orb(val state: OrbView.State) : MyraEvent
    data class Level(val value: Float) : MyraEvent
    data class Hint(val text: String) : MyraEvent
    data class Brain(val online: Boolean) : MyraEvent
    data class Preview(val url: String) : MyraEvent
    data class UiAction(val reply: Reply) : MyraEvent
    data class Wake(val on: Boolean) : MyraEvent
}
