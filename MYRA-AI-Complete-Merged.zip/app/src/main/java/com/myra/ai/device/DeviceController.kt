package com.myra.ai.device

import android.app.admin.DevicePolicyManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import com.myra.ai.automation.MyraAccessibilityService
import java.util.Locale

enum class LockResult { LOCKED, NEEDS_ADMIN }

data class BatteryInfo(val percent: Int, val charging: Boolean, val tempC: Float, val health: String)

data class StorageInfo(val freeBytes: Long, val totalBytes: Long) {
    fun describe(): String =
        String.format(Locale.US, "%.1f GB free of %.0f GB", freeBytes / 1e9, totalBytes / 1e9)
}

/** Local device tools: lock, torch, battery, volume, alarms, storage. */
class DeviceController(private val ctx: Context) {

    private val dpm = (ctx.getSystemService(DevicePolicyManager::class.java) as DevicePolicyManager)
    private val admin = ComponentName(ctx, MyraDeviceAdminReceiver::class.java)
    private val audio = (ctx.getSystemService(AudioManager::class.java) as AudioManager)
    private val camera = (ctx.getSystemService(CameraManager::class.java) as CameraManager)

    // ---------- Lock ----------

    /** Device Admin first (spec), Accessibility lock-screen action (API 28+) as fallback. */
    fun lockNow(): LockResult {
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
            return LockResult.LOCKED
        }
        if (MyraAccessibilityService.instance?.lockScreen() == true) return LockResult.LOCKED
        return LockResult.NEEDS_ADMIN
    }

    fun adminRequestIntent(): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "MYRA needs this only to lock your screen on command.")

    // ---------- Torch ----------

    private val torchId: String? = runCatching {
        camera.cameraIdList.firstOrNull { id ->
            val c = camera.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    fun setTorch(on: Boolean): Boolean {
        val id = torchId ?: return false
        return try {
            camera.setTorchMode(id, on)
            true
        } catch (e: CameraAccessException) {
            false
        }
    }

    // ---------- Battery ----------

    fun battery(): BatteryInfo {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val health = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Unknown"
        }
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return BatteryInfo(if (scale > 0) level * 100 / scale else -1, charging, temp, health)
    }

    // ---------- Volume (media stream) ----------

    fun volumePercent(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
    }

    fun volumeStep(up: Boolean, steps: Int = 2): Int {
        val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        repeat(steps) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, if (it == 0) AudioManager.FLAG_SHOW_UI else 0)
        }
        return volumePercent()
    }

    fun volumeMax() {
        audio.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun mute() {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
    }

    // ---------- Alarm / timer ----------

    fun setAlarm(hour: Int, minute: Int, label: String = "MYRA"): Boolean = launch(
        Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
    )

    fun setTimer(seconds: Int, label: String = "MYRA"): Boolean = launch(
        Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
    )

    private fun launch(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    // ---------- Storage ----------

    fun storage(): StorageInfo {
        val st = StatFs(Environment.getDataDirectory().path)
        return StorageInfo(st.availableBytes, st.totalBytes)
    }
}
