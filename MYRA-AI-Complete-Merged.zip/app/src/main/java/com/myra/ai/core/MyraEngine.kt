package com.myra.ai.core

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import android.os.SystemClock
import com.myra.ai.BuildConfig
import com.myra.ai.ui.OrbView
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.cancellation.CancellationException

/**
 * MYRA's brain-stem. Lives for the whole process, so the foreground service and the UI share it.
 * Flow of an utterance:  local command router (instant, offline)  →  if not recognised, WebSocket to the backend LLM.
 * All heavy work runs on background dispatchers; the UI only renders [events].
 */
class MyraEngine(private val app: Application) {

    private val errorHandler = CoroutineExceptionHandler { _, t ->
        CrashLog.write("engine", t)
        line(Kind.ERR, "SYS", "Internal error recovered (${t.javaClass.simpleName}).")
    }
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + errorHandler)

    private val _events = MutableSharedFlow<MyraEvent>(extraBufferCapacity = 512, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: SharedFlow<MyraEvent> = _events.asSharedFlow()

    private val processing = MutableStateFlow(false)
    private val speaking = MutableStateFlow(false)

    /** true while MYRA is thinking, streaming or talking. The wake-word service pauses itself meanwhile. */
    val busy: StateFlow<Boolean> =
        combine(processing, speaking) { a, b -> a || b }.stateIn(scope, SharingStarted.Eagerly, false)

    @Volatile var brainOnline = false
        private set
    @Volatile var uiAttached = false
    @Volatile var lastPreviewUrl: String? = null
        private set
    @Volatile private var pendingUiReply: Reply? = null

    private val histLock = Any()
    private val history = ArrayList<MyraEvent.Line>()
    private val lineIds = AtomicLong(1)

    private val jobLock = Any()
    private var job: Job? = null
    private val generation = AtomicInteger(0)

    val speaker = Speaker(app) { speaking.value = it }
    val router: CommandRouter by lazy { CommandRouter(app) { msg -> say(msg) } }

    val socket = MyraSocket(BuildConfig.BACKEND_URL, BuildConfig.BACKEND_TOKEN, Prefs.sessionId(app), scope) { online ->
        brainOnline = online
        _events.tryEmit(MyraEvent.Brain(online))
        if (online) line(Kind.SYS, "NET", "Brain connected ✔") else line(Kind.ERR, "NET", "Brain offline. Local commands still work.")
    }

    // ------------------------------------------------------------------ lifecycle

    fun start() {
        Safe.exec("engine.start") {
            line(Kind.BOOT, "BOOT", "MYRA core initialize ho raha hai...")
            line(Kind.BOOT, "BOOT", "Local commands ready  |  voice ${MyraConfig.SPEECH_LANG}")
            val token = BuildConfig.BACKEND_TOKEN
            if (token.isBlank() || token.startsWith("change-me")) {
                line(Kind.ERR, "BOOT", "MYRA_TOKEN set nahi hai (gradle.properties). Brain connect nahi hoga.")
            } else {
                line(Kind.BOOT, "BOOT", "Brain se connect kar rahi hoon...")
            }
            socket.start()
            watchNetwork()
            scope.launch { busy.collect { b -> if (!b) orb(OrbView.State.IDLE) } }
        }
    }

    private fun watchNetwork() = Safe.exec("engine.net") {
        val cm = (app.getSystemService(ConnectivityManager::class.java) as ConnectivityManager)
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                socket.reconnectNow()
            }
        })
    }

    // ------------------------------------------------------------------ events / log

    fun line(kind: Kind, tag: String, text: String): Long {
        val id = lineIds.incrementAndGet()
        upsert(id, kind, tag, text)
        return id
    }

    fun upsert(id: Long, kind: Kind, tag: String, text: String) {
        val e = MyraEvent.Line(id, kind, tag, text)
        synchronized(histLock) {
            var idx = -1
            var i = history.size - 1
            while (i >= 0 && i >= history.size - 30) {
                if (history[i].id == id) {
                    idx = i
                    break
                }
                i--
            }
            if (idx >= 0) {
                history[idx] = e
            } else {
                history.add(e)
                if (history.size > 300) history.removeAt(0)
            }
        }
        _events.tryEmit(e)
    }

    fun history(): List<MyraEvent.Line> = synchronized(histLock) { ArrayList(history) }

    fun orb(s: OrbView.State) { _events.tryEmit(MyraEvent.Orb(s)) }
    fun level(v: Float) { _events.tryEmit(MyraEvent.Level(v)) }
    fun hint(t: String) { _events.tryEmit(MyraEvent.Hint(t)) }

    fun wakeState(on: Boolean) {
        _events.tryEmit(MyraEvent.Wake(on))
        line(Kind.SYS, "WAKE", if (on) "Hands-free on. Bolo: Okay Myra." else "Hands-free off.")
    }

    fun onWake() {
        line(Kind.SYS, "WAKE", "Okay Myra ✔")
        orb(OrbView.State.LISTENING)
    }

    fun say(text: String) {
        line(Kind.MYRA, "MYRA", text)
        orb(OrbView.State.SPEAKING)
        speaker.speak(text)
    }

    fun runAsync(block: () -> Unit) {
        scope.launch(Dispatchers.IO) { Safe.exec("engine.async") { block() } }
    }

    // ------------------------------------------------------------------ utterances

    fun handleUtterance(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        Safe.exec("engine.handle") {
            synchronized(jobLock) {
                job?.cancel()
                speaker.stop()
                val mine = generation.incrementAndGet()
                processing.value = true
                job = scope.launch {
                    try {
                        process(text)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: Throwable) {
                        CrashLog.write("engine.process", t)
                        say("Kuch gadbad ho gayi, Boss, par main zinda hoon. Dobara bolo.")
                    } finally {
                        if (generation.get() == mine) processing.value = false
                    }
                }
            }
        }
    }

    /** Barge-in: stop talking / streaming right now. */
    fun interrupt() {
        Safe.exec("engine.interrupt") {
            synchronized(jobLock) {
                generation.incrementAndGet()
                job?.cancel()
                job = null
                processing.value = false
            }
            speaker.stop()
        }
    }

    private suspend fun process(text: String) {
        line(Kind.YOU, "YOU", text)
        orb(OrbView.State.THINKING)
        val reply: Reply = withContext(Dispatchers.IO) {
            Safe.call<Reply>("router", Reply.Say("Local command parser atak gaya, Boss. Dobara bolo.")) { router.route(text) }
        }
        when (reply) {
            is Reply.Say -> say(reply.text)
            Reply.Unhandled -> askBrain(text)
            is Reply.NeedPermission, is Reply.Verify -> deliverToUi(reply)
        }
    }

    /** Hand a Reply produced elsewhere (UI cards, permission retries) to the right place. */
    fun deliver(reply: Reply) {
        when (reply) {
            is Reply.Say -> say(reply.text)
            Reply.Unhandled -> {}
            is Reply.NeedPermission, is Reply.Verify -> deliverToUi(reply)
        }
    }

    private fun deliverToUi(reply: Reply) {
        if (uiAttached) {
            _events.tryEmit(MyraEvent.UiAction(reply))
        } else {
            pendingUiReply = reply
            say("Is kaam ke liye app kholni padegi, Boss. Permission ya verification screen par hota hai.")
        }
    }

    fun takePendingUiReply(): Reply? = pendingUiReply.also { pendingUiReply = null }

    // ------------------------------------------------------------------ backend streaming

    private suspend fun askBrain(text: String) {
        if (!socket.online) {
            say("Dimaag (server) abhi offline hai, Boss. Local commands chalte rahenge: torch, call, alarm, WhatsApp.")
            return
        }
        val id = UUID.randomUUID().toString().substring(0, 8)
        val ch = socket.openStream(id)
        var finished = false
        try {
            if (!socket.send(JSONObject().put("type", "ask").put("id", id).put("text", text))) {
                finished = true
                say("Server tak baat pahunchi nahi, Boss. Ek baar aur bolo.")
                return
            }
            val replyLine = lineIds.incrementAndGet()
            val reply = StringBuilder()
            val chunker = SentenceChunker { speaker.speak(it) }
            val codeLines = HashMap<String, Long>()
            val codeSizes = HashMap<String, Int>()
            val codeTails = HashMap<String, String>()
            var lastReplyUi = 0L
            var lastCodeUi = 0L
            var gotToken = false

            while (true) {
                val r = withTimeoutOrNull(MyraConfig.STREAM_IDLE_MS) { ch.receiveCatching() }
                if (r == null) {
                    say("Server ne jawab dena band kar diya, Boss. Timeout.")
                    return
                }
                if (r.isClosed) {
                    say("Connection beech mein toot gaya, Boss. Wapas jod rahi hoon.")
                    finished = true
                    return
                }
                val m = r.getOrNull() ?: continue
                when (m.type) {
                    "mode" -> if (m.str("mode") == "code") {
                        line(Kind.SYS, "BUILD", "Website build mode on.")
                        speaker.speak("Theek hai Boss, bana rahi hoon.")
                    }
                    "log" -> line(Kind.SYS, "NET", m.str("text"))
                    "token" -> {
                        val t = m.str("text")
                        reply.append(t)
                        chunker.feed(t)
                        if (!gotToken) {
                            gotToken = true
                            orb(OrbView.State.SPEAKING)
                        }
                        val now = SystemClock.uptimeMillis()
                        if (now - lastReplyUi > 60) {
                            lastReplyUi = now
                            upsert(replyLine, Kind.MYRA, "MYRA", reply.toString())
                        }
                    }
                    "code_chunk" -> {
                        val f = m.str("file")
                        val t = m.str("text")
                        codeSizes[f] = (codeSizes[f] ?: 0) + t.length
                        codeTails[f] = ((codeTails[f] ?: "") + t).takeLast(90)
                        val lid = codeLines.getOrPut(f) { lineIds.incrementAndGet() }
                        val now = SystemClock.uptimeMillis()
                        if (now - lastCodeUi > 80) {
                            lastCodeUi = now
                            upsert(lid, Kind.CODE, "CODE", "$f ▸ ${codeTails[f].orEmpty().replace('\n', ' ')}")
                        }
                    }
                    "file_done" -> {
                        val f = m.str("file")
                        val lid = codeLines.getOrPut(f) { lineIds.incrementAndGet() }
                        upsert(lid, Kind.CODE, "CODE", "✔ $f (${m.int("bytes")} B)")
                    }
                    "preview" -> {
                        val url = MyraConfig.httpBase + m.str("url")
                        lastPreviewUrl = url
                        _events.tryEmit(MyraEvent.Preview(url))
                        say("Website tayyar hai, Boss. Preview khol rahi hoon.")
                    }
                    "done" -> {
                        finished = true
                        if (reply.isNotEmpty()) upsert(replyLine, Kind.MYRA, "MYRA", reply.toString())
                        chunker.flush()
                        return
                    }
                    "error" -> {
                        finished = true
                        say(m.str("message").ifBlank { "Server se error aaya, Boss." })
                        return
                    }
                }
            }
        } finally {
            socket.closeStream(id)
            if (!finished) socket.cancel(id)
        }
    }
}
