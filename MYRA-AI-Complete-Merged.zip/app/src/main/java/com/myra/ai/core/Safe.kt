package com.myra.ai.core

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.cancellation.CancellationException

/** Tiny rotating log in filesDir/myra.log; never throws. */
object CrashLog {
    @Volatile
    private var file: File? = null

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "myra.log")
    }

    @Synchronized
    fun write(tag: String, t: Throwable?, msg: String? = null) {
        try {
            Log.e("MYRA/$tag", msg ?: t?.message ?: "error", t)
        } catch (_: Throwable) {
        }
        val f = file ?: return
        try {
            if (f.length() > 200_000) f.writeText("")
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            f.appendText("$ts [$tag] ${msg.orEmpty()} ${t?.stackTraceToString().orEmpty()}\n")
        } catch (_: Throwable) {
        }
    }
}

/** Run risky code without ever propagating (coroutine cancellation is still honoured). */
object Safe {
    inline fun <T> call(tag: String, fallback: T, block: () -> T): T =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            CrashLog.write(tag, t)
            fallback
        }

    inline fun exec(tag: String, block: () -> Unit) {
        call(tag, Unit, block)
    }
}
