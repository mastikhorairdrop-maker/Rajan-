package com.myra.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.myra.ai.core.CrashLog
import com.myra.ai.core.Kind
import com.myra.ai.core.MyraConfig
import com.myra.ai.core.MyraEngine
import com.myra.ai.core.MyraEvent
import com.myra.ai.core.Prefs
import com.myra.ai.core.Reply
import com.myra.ai.core.Safe
import com.myra.ai.databinding.ActivityMainBinding
import com.myra.ai.security.BossAuth
import com.myra.ai.service.WakeWordService
import com.myra.ai.ui.ActionAdapter
import com.myra.ai.ui.LogAdapter
import com.myra.ai.ui.OrbView
import com.myra.ai.ui.PreviewActivity
import com.myra.ai.ui.QuickAction
import kotlinx.coroutines.launch

/** A thin view over [MyraEngine]: renders its events and forwards taps. No business logic lives here. */
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val logAdapter = LogAdapter()
    private val engine: MyraEngine get() = (application as MyraApp).engine

    private var recognizer: SpeechRecognizer? = null
    private var localListening = false
    private var pendingRetry: (() -> Reply)? = null
    private var afterMic: (() -> Unit)? = null
    private var askedNotif = false
    private var ignoreSwitch = false

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val next = afterMic
            afterMic = null
            if (granted) {
                Safe.exec("mic.next") { next?.invoke() }
            } else {
                engine.line(Kind.ERR, "SYS", "Mic permission nahi mili, Boss. Bina kaan ke kaise sunu?")
                setSwitch(false)
            }
        }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startWakeService() }

    private val permissionRequest =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val retry = pendingRetry
            pendingRetry = null
            if (granted && retry != null) {
                engine.runAsync { engine.deliver(retry()) }
            } else {
                engine.line(Kind.ERR, "SYS", "Permission nahi mili, Boss. Ye kaam ab nahi ho paayega.")
            }
        }

    private val actions = listOf(
        QuickAction("whatsapp", "WhatsApp", R.drawable.ic_chat, R.color.ok_green),
        QuickAction("voice", "Voice Assistant", R.drawable.ic_mic, R.color.neon_purple),
        QuickAction("screen", "Screen Automation", R.drawable.ic_screen, R.color.cyan),
        QuickAction("device", "Device Tools", R.drawable.ic_lock, R.color.electric_red),
        QuickAction("code", "Code Builder", R.drawable.ic_code, R.color.neon_purple)
    )

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        Safe.exec("ui.setup") {
            b.logList.layoutManager = LinearLayoutManager(this)
            b.logList.adapter = logAdapter
            b.logList.itemAnimator = null
            b.actionGrid.layoutManager = GridLayoutManager(this, 3)
            b.actionGrid.adapter = ActionAdapter(actions, ::onAction)
            b.orbView.setOnClickListener { Safe.exec("orb.tap") { onOrbTap() } }
            b.wakeSwitch.setOnCheckedChangeListener { _, checked ->
                if (!ignoreSwitch) Safe.exec("wake.toggle") { if (checked) enableWake() else disableWake() }
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Safe.exec("ui.hydrate") { hydrate() }
                engine.events.collect { e -> Safe.exec("ui.render") { render(e) } }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Safe.exec("ui.onStart") {
            engine.uiAttached = true
            engine.takePendingUiReply()?.let { handleUiReply(it) }
            if (Prefs.wakeEnabled(this) && hasMic() && !WakeWordService.running) WakeWordService.start(this)
        }
    }

    override fun onStop() {
        Safe.exec("ui.onStop") {
            engine.uiAttached = false
            stopLocalListening()
        }
        super.onStop()
    }

    override fun onDestroy() {
        Safe.exec("ui.onDestroy") {
            recognizer?.destroy()
            recognizer = null
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ rendering

    private fun hydrate() {
        logAdapter.setAll(engine.history().map { toLine(it) })
        scrollBottom()
        setBrain(engine.brainOnline)
        setSwitch(WakeWordService.running)
    }

    private fun render(e: MyraEvent) {
        when (e) {
            is MyraEvent.Line -> {
                logAdapter.upsert(toLine(e))
                scrollBottom()
            }
            is MyraEvent.Orb -> setOrb(e.state)
            is MyraEvent.Level -> b.orbView.setLevel(e.value)
            is MyraEvent.Hint -> b.stateText.text = e.text
            is MyraEvent.Brain -> setBrain(e.online)
            is MyraEvent.Preview -> PreviewActivity.open(this, e.url)
            is MyraEvent.UiAction -> handleUiReply(e.reply)
            is MyraEvent.Wake -> setSwitch(e.on)
        }
    }

    private fun toLine(e: MyraEvent.Line): LogAdapter.Line {
        val color = when (e.kind) {
            Kind.BOOT, Kind.YOU -> R.color.cyan
            Kind.SYS -> R.color.text_dim
            Kind.ERR -> R.color.electric_red
            Kind.MYRA -> R.color.neon_purple
            Kind.CODE -> R.color.ok_green
        }
        return LogAdapter.Line(e.id, e.tag, e.text, ContextCompat.getColor(this, color))
    }

    private fun scrollBottom() {
        if (logAdapter.itemCount > 0) b.logList.scrollToPosition(logAdapter.itemCount - 1)
    }

    private fun setOrb(s: OrbView.State) {
        b.orbView.state = s
        b.stateText.text = when (s) {
            OrbView.State.IDLE -> if (WakeWordService.running) "Say “Okay Myra”" else "Tap the orb to speak"
            OrbView.State.LISTENING -> "Listening..."
            OrbView.State.THINKING -> "Processing..."
            OrbView.State.SPEAKING -> "MYRA speaking"
        }
        if (s != OrbView.State.LISTENING) b.orbView.setLevel(0f)
    }

    private fun setBrain(online: Boolean) {
        val color = ContextCompat.getColor(this, if (online) R.color.ok_green else R.color.electric_red)
        b.statusDot.backgroundTintList = ColorStateList.valueOf(color)
        b.statusText.text = if (online) "Brain online" else "Local mode"
    }

    private fun setSwitch(on: Boolean) {
        ignoreSwitch = true
        b.wakeSwitch.isChecked = on
        ignoreSwitch = false
    }

    // ------------------------------------------------------------------ hands-free

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun enableWake() {
        if (!hasMic()) {
            afterMic = ::enableWake
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startWakeService()
    }

    private fun startWakeService() {
        val ok = WakeWordService.start(this)
        Prefs.setWake(this, ok)
        setSwitch(ok)
        if (!ok) engine.line(Kind.ERR, "WAKE", "Hands-free start nahi ho paya, Boss.")
    }

    private fun disableWake() {
        Prefs.setWake(this, false)
        WakeWordService.stop(this)
    }

    // ------------------------------------------------------------------ voice (tap-to-talk)

    private fun onOrbTap() {
        if (engine.busy.value) engine.interrupt()
        when {
            WakeWordService.running -> WakeWordService.talk(this)
            localListening -> stopLocalListening()
            hasMic() -> startLocalListening()
            else -> {
                afterMic = ::startLocalListening
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun startLocalListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            engine.line(Kind.ERR, "SYS", "Speech recognition is device par available nahi hai.")
            return
        }
        try {
            val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(localListener)
                recognizer = it
            }
            localListening = true
            engine.orb(OrbView.State.LISTENING)
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, MyraConfig.SPEECH_LANG)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                }
            )
        } catch (t: Throwable) {
            CrashLog.write("ui.listen", t)
            localListening = false
            Safe.exec("ui.listen.reset") { recognizer?.destroy() }
            recognizer = null
            engine.orb(OrbView.State.IDLE)
            engine.line(Kind.ERR, "SYS", "Mic start nahi hua, Boss. Dobara tap karo.")
        }
    }

    private fun stopLocalListening() {
        if (!localListening) return
        localListening = false
        Safe.exec("ui.listen.stop") { recognizer?.cancel() }
        engine.orb(OrbView.State.IDLE)
    }

    private val localListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            engine.level(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
        }

        override fun onPartialResults(partialResults: Bundle?) {
            partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                ?.takeIf { it.isNotBlank() }?.let { engine.hint(it) }
        }

        override fun onResults(results: Bundle?) {
            localListening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) engine.orb(OrbView.State.IDLE) else engine.handleUtterance(text)
        }

        override fun onError(error: Int) {
            localListening = false
            engine.orb(OrbView.State.IDLE)
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch suna hi nahi, Boss. Dobara bolo."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network ka scene kharab hai."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    Safe.exec("ui.listen.busy") { recognizer?.destroy() }
                    recognizer = null
                    "Mic abhi busy hai, Boss. Ek second ruko."
                }
                else -> "Voice error (code $error)."
            }
            engine.line(Kind.ERR, "SYS", msg)
        }
    }

    // ------------------------------------------------------------------ cards / permission & verification flows

    private fun onAction(a: QuickAction) {
        Safe.exec("ui.action") {
            when (a.id) {
                "voice" -> onOrbTap()
                "whatsapp" -> engine.runAsync { engine.deliver(engine.router.openWhatsApp()) }
                "screen" -> engine.runAsync { engine.deliver(engine.router.screenStatus()) }
                "device" -> engine.runAsync { engine.say(engine.router.deviceReport()) }
                "code" -> {
                    val last = engine.lastPreviewUrl
                    if (last != null) PreviewActivity.open(this, last)
                    else engine.say("Bolo: 'ek dark portfolio website banao', Boss. Main build karke yahin dikha dungi.")
                }
            }
        }
    }

    private fun handleUiReply(reply: Reply) {
        when (reply) {
            is Reply.NeedPermission -> {
                engine.say(reply.say)
                pendingRetry = reply.retry
                permissionRequest.launch(reply.permission)
            }
            is Reply.Verify -> {
                engine.say(reply.say)
                BossAuth.verify(
                    this,
                    onSuccess = { engine.runAsync { engine.deliver(reply.onVerified()) } },
                    onFail = { engine.line(Kind.ERR, "SYS", it) }
                )
            }
            else -> engine.deliver(reply)
        }
    }
}
