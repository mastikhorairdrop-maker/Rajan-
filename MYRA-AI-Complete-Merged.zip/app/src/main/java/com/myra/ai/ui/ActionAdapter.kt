package com.myra.ai.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.myra.ai.R

data class QuickAction(
    val id: String,
    val label: String,
    @DrawableRes val icon: Int,
    @ColorRes val tint: Int
)

/** Glassmorphism quick-action grid. */
class ActionAdapter(
    private val actions: List<QuickAction>,
    private val onClick: (QuickAction) -> Unit
) : RecyclerView.Adapter<ActionAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
        LayoutInflater.from(parent.context).inflate(R.layout.item_action_card, parent, false)
    )

    override fun onBindViewHolder(holder: VH, position: Int) {
        val a = actions[position]
        holder.icon.setImageResource(a.icon)
        holder.icon.setColorFilter(ContextCompat.getColor(holder.itemView.context, a.tint))
        holder.label.text = a.label
        holder.itemView.setOnClickListener { onClick(a) }
    }

    override fun getItemCount() = actions.size
}
