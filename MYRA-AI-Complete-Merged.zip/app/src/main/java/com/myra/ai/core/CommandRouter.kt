package com.myra.ai.core

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.myra.ai.automation.MyraAccessibilityService
import com.myra.ai.comms.CommsController
import com.myra.ai.device.DeviceController
import com.myra.ai.device.LockResult
import java.text.Normalizer
import java.util.Locale

/** What MYRA wants to do after parsing a command. */
sealed class Reply {
    data class Say(val text: String) : Reply()
    data class NeedPermission(val permission: String, val say: String, val retry: () -> Reply) : Reply()
    data class Verify(val say: String, val onVerified: () -> Reply) : Reply()
    /** Not a local command: the engine forwards it to the backend LLM. */
    object Unhandled : Reply()
}

internal sealed class Target {
    data class Ok(val name: String, val number: String) : Target()
    data class Ask(val reply: Reply) : Target()
}

/**
 * Rule-based Hinglish / Hindi / English command parser for on-device actions.
 * Stage 3 replaces this with LLM tool-calling; the actions below stay the same.
 * Entries ending in "\$" must match a whole word; other single words match as prefixes.
 */
class CommandRouter(private val ctx: Context, private val async: (String) -> Unit) {

    private val device = DeviceController(ctx)
    private val comms = CommsController(ctx)
    private val a11y: MyraAccessibilityService? get() = MyraAccessibilityService.instance

    private object Lex {
        val unlock = listOf("unlock", "अनलॉक", "अनलोक")
        val lock = listOf("lock", "लॉक")
        val torch = listOf("torch", "torch", "flashlight", "flash light", "टॉर्च", "टोर्च", "टार्च", "फ्लैशलाइट", "फ्लैश लाइट")
        val off = listOf("off\$", "band", "bujha", "बंद", "बन्द", "बुझा", "ऑफ")
        val up = listOf("up\$", "badh", "increase", "zyada", "tez", "loud", "बढ", "ज्यादा", "ज़्यादा", "तेज")
        val down = listOf("down\$", "kam", "ghata", "decrease", "dheere", "low\$", "घटा", "कम", "धीरे")
        val mute = listOf("mute", "silent", "म्यूट", "साइलेंट")
        val max = listOf("max", "full", "poora", "पूरा")
        val battery = listOf("battery", "बैटरी", "charge", "चार्ज")
        val storage = listOf("storage", "space\$", "jagah", "स्टोरेज", "जगह")
        val volume = listOf("volume", "awaaz", "awaz", "sound\$", "वॉल्यूम", "आवाज", "साउंड")
        val alarm = listOf("alarm", "अलार्म")
        val timer = listOf("timer", "टाइमर")
        val pm = listOf("pm\$", "shaam", "sham", "raat", "dopahar", "शाम", "रात", "दोपहर")
        val am = listOf("am\$", "subah", "सुबह")
        val whatsapp = listOf("whatsapp", "whats app", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप", "वाट्सऐप", "व्हाट्स ऐप", "व्हाट्स अप")
        val call = listOf("call", "कॉल", "dial", "phone kar", "फोन कर", "फ़ोन कर")
        val sms = listOf("sms", "message", "msg", "text\$", "मैसेज", "मेसेज", "एसएमएस")
        val readScreen = listOf("read screen", "screen read", "screen padh", "screen par kya", "screen pe kya", "स्क्रीन पढ़", "स्क्रीन पर क्या")
        val click = listOf("click", "tap\$", "press", "dabao", "क्लिक", "टैप", "दबाओ")
        val scroll = listOf("scroll", "स्क्रॉल")
        val scrollUp = listOf("up\$", "upar", "ऊपर")
        val back = listOf("go back", "back jao", "wapas", "पीछे", "बैक")
        val home = listOf("go home", "home screen", "home jao", "होम स्क्रीन", "होम जाओ")
        val recents = listOf("recent apps", "recents", "रीसेंट")

        val sendLabels = listOf("Send", "भेजें")
        val voiceCall = listOf("Voice call", "वॉइस कॉल", "Audio call")
        val callConfirm = listOf("Call", "कॉल")

        val stop = setOf(
            "call", "कॉल", "dial", "phone", "फोन", "फ़ोन", "kar", "karo", "kardo", "do", "कर", "करो", "दो",
            "please", "plz", "ko", "को", "lagao", "लगाओ", "लगा", "mujhe", "whatsapp", "व्हाट्सएप", "व्हाट्सऐप",
            "वॉट्सऐप", "वाट्सएप", "वाट्सऐप", "sms", "message", "msg", "text", "मैसेज", "मेसेज", "send", "to",
            "bhejo", "bhej", "भेजो", "भेज", "a", "the", "on", "par", "pe", "पर", "पे", "video", "voice",
            "karna", "करना", "chahiye", "ek", "एक", "kholo", "खोलो", "open", "खोल", "app"
        )
        val clickStop = setOf(
            "click", "tap", "press", "dabao", "kar", "karo", "par", "pe", "on", "the", "button",
            "क्लिक", "टैप", "दबाओ", "कर", "करो", "पर", "पे", "बटन"
        )
    }

    // ------------------------------------------------------------ entry point

    fun route(raw: String): Reply {
        val text = norm(raw.trim(), lower = false)
        val t = norm(text)

        Regex("^(?:type|likho|लिखो|टाइप)\\s+(.+)\$", RegexOption.IGNORE_CASE).find(text)?.let {
            return typeText(it.groupValues[1])
        }

        return when {
            has(t, Lex.unlock) -> unlock()
            has(t, Lex.lock) -> lock()
            has(t, Lex.torch) -> torch(!has(t, Lex.off))
            has(t, Lex.battery) -> Reply.Say(batteryLine())
            has(t, Lex.storage) -> Reply.Say(storageLine())
            has(t, Lex.volume) -> volume(t)
            has(t, Lex.timer) -> timer(t)
            has(t, Lex.alarm) -> alarm(t)
            has(t, Lex.whatsapp) -> whatsapp(text, t)
            has(t, Lex.call) -> call(cleanTarget(t), text)
            has(t, Lex.sms) -> smsCommand(text)
            has(t, Lex.readScreen) -> readScreen()
            has(t, Lex.scroll) -> withA11y { svc ->
                val fwd = !has(t, Lex.scrollUp)
                if (svc.scroll(fwd)) Reply.Say("Scroll kar diya.") else Reply.Say("Yahan scroll hone layak kuch nahi mila, Boss.")
            }
            has(t, Lex.back) -> withA11y { Reply.Say(if (it.back()) "Peeche aa gayi." else "Back nahi ho paya.") }
            has(t, Lex.home) -> withA11y { Reply.Say(if (it.home()) "Home par." else "Home nahi ho paya.") }
            has(t, Lex.recents) -> withA11y { Reply.Say(if (it.recents()) "Recent apps khol diye." else "Recents nahi khule.") }
            has(t, Lex.click) -> click(t)
            else -> Reply.Unhandled
        }
    }

    // ------------------------------------------------------------ public helpers for the UI cards

    fun openWhatsApp(): Reply {
        val i = comms.whatsappLaunch() ?: return Reply.Say("WhatsApp is phone mein mila hi nahi, Boss.")
        ctx.startActivity(i)
        return Reply.Say("WhatsApp khol diya. Ab bolo kisko kya bhejna hai.")
    }

    fun screenStatus(): Reply =
        if (a11y != null) {
            Reply.Say("Screen Automation active hai, Boss. Bolo: 'screen padho', 'scroll down', 'click send', 'type hello'.")
        } else {
            openA11ySettings()
        }

    fun deviceReport(): String =
        "${batteryLine()} ${storageLine()} Volume ${device.volumePercent()}%."

    // ------------------------------------------------------------ device commands

    private fun unlock() = Reply.Verify(
        "Unlock main nahi kar sakti, Boss. Android ye power kisi app ko deta hi nahi. Fingerprint do, pehchaan main kar leti hoon."
    ) { Reply.Say("Boss verified. Ab phone tum khud khol lo, main taala nahi tod sakti.") }

    private fun lock(): Reply = when (device.lockNow()) {
        LockResult.LOCKED -> Reply.Say("Lock kar diya, Boss. Chup-chaap.")
        LockResult.NEEDS_ADMIN -> {
            ctx.startActivity(device.adminRequestIntent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Reply.Say("Lock ke liye pehle Device Admin allow karo, Boss. 'Activate' dabao, bas ek baar ka kaam hai.")
        }
    }

    private fun torch(on: Boolean): Reply =
        if (device.setTorch(on)) {
            Reply.Say(if (on) "Torch on. Andhere mein Boss ko rasta dikhana mera kaam hai." else "Torch off.")
        } else {
            Reply.Say("Flash mila nahi, ya camera abhi kisi aur app ke paas hai.")
        }

    private fun batteryLine(): String {
        val b = device.battery()
        val state = if (b.charging) "charging ho rahi hai" else "charging nahi ho rahi"
        val temp = String.format(Locale.US, "%.1f", b.tempC)
        return "Battery ${b.percent}% hai, ${state}. Temp ${temp}°C, health ${b.health}."
    }

    private fun storageLine() = "Storage: ${device.storage().describe()}."

    private fun volume(t: String): Reply = when {
        has(t, Lex.mute) || has(t, Lex.off) -> { device.mute(); Reply.Say("Mute. Shanti.") }
        has(t, Lex.max) -> { device.volumeMax(); Reply.Say("Volume full. Padosi ko pehle bata dena.") }
        has(t, Lex.up) -> Reply.Say("Volume ${device.volumeStep(true)}% kar diya.")
        has(t, Lex.down) -> Reply.Say("Volume ${device.volumeStep(false)}% kar diya.")
        else -> Reply.Say("Volume abhi ${device.volumePercent()}% hai, Boss. 'badhao' ya 'kam karo' bolo.")
    }

    private fun alarm(t: String): Reply {
        val m = Regex("(\\d{1,2})(?:[:.](\\d{1,2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(t)
            ?: return Reply.Say("Kitne baje ka alarm, Boss? '7 baje ka alarm' bolo.")
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val mer = m.groupValues[3].replace(".", "")
        if (h > 23 || min > 59) return Reply.Say("Ye time samajh nahi aaya, Boss.")
        val pm = mer == "pm" || (mer.isEmpty() && has(t, Lex.pm))
        val am = mer == "am" || (mer.isEmpty() && has(t, Lex.am))
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (has(t, listOf("raat", "रात")) && h == 12) h = 0
        val label = "%02d:%02d".format(Locale.US, h, min)
        return if (device.setAlarm(h, min)) Reply.Say("Alarm set: $label. Uthne ki zimmedari tumhari.")
        else Reply.Say("Clock app alarm lene se mana kar raha hai, Boss.")
    }

    private fun timer(t: String): Reply {
        val m = Regex("(\\d+)\\s*(hour|hr|घंट|min|मिनट|sec|second|सेकंड|सेकण्ड)").find(t)
            ?: return Reply.Say("Kitne der ka timer? '5 minute ka timer' bolo.")
        val unit = m.groupValues[2]
        val mult = when {
            unit.startsWith("h") || unit.startsWith("घ") -> 3600
            unit.startsWith("m") || unit.startsWith("म") -> 60
            else -> 1
        }
        val secs = m.groupValues[1].toInt() * mult
        return if (device.setTimer(secs)) Reply.Say("Timer shuru: ${m.groupValues[1]} ${m.groupValues[2]}.")
        else Reply.Say("Timer set nahi ho paya, Boss.")
    }

    // ------------------------------------------------------------ communication

    private fun call(target: String, raw: String): Reply {
        if (target.isBlank()) return Reply.Say("Kisko call karun, Boss? 'Rahul ko call karo' bolo.")
        val who = when (val tg = resolve(target, raw)) {
            is Target.Ask -> return tg.reply
            is Target.Ok -> tg
        }
        if (!granted(Manifest.permission.CALL_PHONE)) {
            return Reply.NeedPermission(Manifest.permission.CALL_PHONE, "Call lagane ki permission chahiye, Boss.") { route(raw) }
        }
        comms.call(who.number)
        return Reply.Say("${who.name} ko call laga rahi hoon.")
    }

    private fun smsCommand(raw: String): Reply {
        val (name, body) = parseMessage(raw)
            ?: return Reply.Say("Kisko kya bhejna hai? 'Rahul ko sms karo ki main late hoon' bolo.")
        val who = when (val tg = resolve(name, raw)) {
            is Target.Ask -> return tg.reply
            is Target.Ok -> tg
        }
        if (!granted(Manifest.permission.SEND_SMS)) {
            return Reply.NeedPermission(Manifest.permission.SEND_SMS, "SMS bhejne ki permission chahiye, Boss.") { route(raw) }
        }
        return try {
            comms.sendSms(who.number, body)
            Reply.Say("${who.name} ko SMS bhej diya: \"$body\"")
        } catch (e: Exception) {
            Reply.Say("SMS fail ho gaya: ${e.message}")
        }
    }

    private fun whatsapp(raw: String, t: String): Reply {
        if (has(t, Lex.call)) {
            val target = cleanTarget(t)
            return if (target.isBlank()) Reply.Say("Kisko WhatsApp call karun, Boss?") else whatsappCall(target, raw)
        }
        parseMessage(raw)?.let { (name, body) -> return whatsappMessage(name, body, raw) }
        val target = cleanTarget(t)
        return if (target.isBlank()) openWhatsApp()
        else Reply.Say("$target ko kya bhejna hai? 'Rahul ko whatsapp karo ki main late hoon' bolo.")
    }

    private fun whatsappMessage(name: String, body: String, raw: String): Reply {
        val who = when (val tg = resolve(name, raw)) {
            is Target.Ask -> return tg.reply
            is Target.Ok -> tg
        }
        val intent = comms.whatsappIntent(comms.whatsappNumber(who.number), body)
            ?: return Reply.Say("WhatsApp is phone mein mila hi nahi, Boss.")
        ctx.startActivity(intent)
        if (!MyraConfig.WHATSAPP_AUTO_SEND) {
            return Reply.Say("${who.name} ki chat khol di, message ready hai. Send tum dabao.")
        }
        val svc = a11y
            ?: return Reply.Say("Chat khol di, message ready hai. Auto-send ke liye Accessibility on karo, Boss.")
        svc.clickWhenAvailable(Lex.sendLabels) { ok ->
            async(if (ok) "Bhej diya, Boss." else "Send button nahi mila. Chat khuli hai, haath se daba do.")
        }
        return Reply.Say("${who.name} ko bhej rahi hoon: \"$body\"")
    }

    private fun whatsappCall(name: String, raw: String): Reply {
        val who = when (val tg = resolve(name, raw)) {
            is Target.Ask -> return tg.reply
            is Target.Ok -> tg
        }
        val intent = comms.whatsappIntent(comms.whatsappNumber(who.number), null)
            ?: return Reply.Say("WhatsApp is phone mein mila hi nahi, Boss.")
        ctx.startActivity(intent)
        val svc = a11y
            ?: return Reply.Say("Chat khol di. Call button dabane ke liye Accessibility on karo, Boss.")
        svc.clickWhenAvailable(Lex.voiceCall) { ok ->
            if (ok) {
                svc.clickWhenAvailable(Lex.callConfirm, 3000L) { }
                async("WhatsApp call laga rahi hoon...")
            } else {
                async("Call button nahi mila. WhatsApp ka layout badal gaya ho sakta hai.")
            }
        }
        return Reply.Say("${who.name} ko WhatsApp call kar rahi hoon.")
    }

    // ------------------------------------------------------------ screen automation

    private fun readScreen(): Reply = withA11y { svc ->
        val s = svc.readScreen()
        if (s.isBlank()) Reply.Say("Screen khaali dikh rahi hai, ya app ne padhne se mana kar diya.")
        else Reply.Say("Screen par ye hai: $s")
    }

    private fun click(t: String): Reply = withA11y { svc ->
        val label = cleanWith(t, Lex.clickStop)
        when {
            label.isBlank() -> Reply.Say("Kya dabana hai, Boss? 'click send' jaisa bolo.")
            svc.clickByText(listOf(label), loose = true) -> Reply.Say("'$label' daba diya.")
            else -> Reply.Say("'$label' naam ka button screen par nahi mila.")
        }
    }

    private fun typeText(s: String): Reply = withA11y { svc ->
        if (svc.typeText(s)) Reply.Say("Likh diya: \"$s\"") else Reply.Say("Koi text box focus mein nahi mila, Boss.")
    }

    private fun withA11y(block: (MyraAccessibilityService) -> Reply): Reply {
        val svc = a11y ?: return openA11ySettings()
        return block(svc)
    }

    private fun openA11ySettings(): Reply {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return Reply.Say("Accessibility service band hai, Boss. Settings khol di. 'MYRA Screen Automation' on kar do.")
    }

    // ------------------------------------------------------------ parsing helpers

    private fun resolve(name: String, raw: String): Target {
        val digits = name.filter { it.isDigit() || it == '+' }
        if (digits.length >= 7 && name.none { it.isLetter() }) return Target.Ok(digits, digits)
        if (!granted(Manifest.permission.READ_CONTACTS)) {
            return Target.Ask(
                Reply.NeedPermission(Manifest.permission.READ_CONTACTS, "Contacts dekhne ki permission chahiye, Boss.") { route(raw) }
            )
        }
        val hit = comms.findContact(name)
            ?: return Target.Ask(Reply.Say("'$name' naam ka koi contact nahi mila, Boss."))
        return Target.Ok(hit.first, hit.second)
    }

    /** "Rahul ko whatsapp karo ki main late hoon" → ("rahul", "main late hoon") */
    private fun parseMessage(text: String): Pair<String, String>? {
        val o = RegexOption.IGNORE_CASE
        val patterns = listOf(
            Regex(
                "^(?:please\\s+)?(.+?)\\s+(?:ko|को)\\s+(?:whatsapp|व्हाट्सएप|व्हाट्सऐप|sms|text|message|msg|मैसेज|मेसेज)" +
                    "\\s*(?:karo|kar|bhejo|bhej do|bhej|send|करो|कर|भेजो|भेज दो|भेज)?\\s*(?:ki|ke|that|कि|के)?\\s*[:,]?\\s*(.+)\$", o
            ),
            Regex("(?:whatsapp|sms|text|message|msg)\\s+(?:to\\s+)?(.+?)\\s+(?:saying|that|ki|:)\\s+(.+)\$", o),
            Regex("send\\s+(?:a\\s+)?(?:whatsapp|sms|text|message)?\\s*to\\s+(.+?)\\s+(?:saying|that)\\s+(.+)\$", o)
        )
        for (p in patterns) {
            val m = p.find(text) ?: continue
            val name = cleanTarget(norm(m.groupValues[1]))
            val body = m.groupValues[2].trim()
            if (name.isNotBlank() && body.isNotBlank()) return name to body
        }
        return null
    }

    private fun cleanTarget(t: String) = cleanWith(t, Lex.stop)

    private fun cleanWith(t: String, stop: Set<String>): String {
        val stopN = stop.map { norm(it) }.toSet()
        return t.split(Regex("\\s+")).filter { it.isNotBlank() && norm(it) !in stopN }.joinToString(" ")
    }

    private fun has(t: String, words: List<String>): Boolean {
        val toks = t.split(Regex("\\s+"))
        return words.any { raw ->
            val w = norm(raw)
            when {
                w.contains(' ') -> t.contains(w)
                w.endsWith("\$") -> toks.any { it == w.dropLast(1) }
                else -> toks.any { it.startsWith(w) }
            }
        }
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

    private fun norm(s: String, lower: Boolean = true): String {
        val n = Normalizer.normalize(s, Normalizer.Form.NFC)
        return if (lower) n.lowercase(Locale.ROOT) else n
    }
}
