package com.myra.ai.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Confirms it's really the Boss (fingerprint / face / PIN).
 * Note: Android never lets an app unlock the phone; this only verifies identity inside MYRA.
 */
object BossAuth {

    private val AUTH: Int = BiometricManager.Authenticators.BIOMETRIC_WEAK or
        BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun verify(activity: FragmentActivity, onSuccess: () -> Unit, onFail: (String) -> Unit) {
        if (BiometricManager.from(activity).canAuthenticate(AUTH) != BiometricManager.BIOMETRIC_SUCCESS) {
            onFail("Phone par fingerprint ya PIN set nahi hai, Boss.")
            return
        }
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onSuccess()
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) =
                    onFail("Verification cancel / fail: $errString")
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("MYRA — Boss verification")
            .setSubtitle("Pehchaan do, phir baat karte hain")
            .setAllowedAuthenticators(AUTH)
            .build()
        prompt.authenticate(info)
    }
}
