plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.myra.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.myra.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "0.3.0"

        // Set these in gradle.properties (or ~/.gradle/gradle.properties)
        val backend = (project.findProperty("MYRA_BACKEND_URL") as String?) ?: "ws://10.0.2.2:8000/ws"
        val token = (project.findProperty("MYRA_TOKEN") as String?) ?: ""
        buildConfigField("String", "BACKEND_URL", "\"$backend\"")
        buildConfigField("String", "BACKEND_TOKEN", "\"$token\"")
        manifestPlaceholders["usesCleartext"] = "false"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    buildTypes {
        debug { manifestPlaceholders["usesCleartext"] = "true" }   // allows ws:// / http:// while developing
        release { isMinifyEnabled = false }                         // release = wss:// / https:// only
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
