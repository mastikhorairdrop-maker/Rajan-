import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from codegen import FileStreamParser, sanitize_filename, looks_like_build_request, strip_fences, CodegenError

SAMPLE = (
    "===FILE: index.html===\n<html><body>hi</body></html>\n===END===\n"
    "===FILE: ../evil.html===\nnope\n===END===\n"
    "===FILE: style.css===\nbody{color:red}\n===END===\n"
    "===FILE: logo.png===\nbinary\n===END===\n"
)


def collect(chunk_size):
    p, ev = FileStreamParser(), []
    for i in range(0, len(SAMPLE), chunk_size):
        ev += p.feed(SAMPLE[i:i + chunk_size])
    ev += p.finish()
    return ev


def test_chunking_does_not_change_result():
    for size in (1, 2, 3, 7, 50, 10_000):
        ev = collect(size)
        files = {}
        for e in ev:
            if e[0] == "chunk":
                files.setdefault(e[1], []).append(e[2])
        assert set(files) == {"index.html", "style.css"}, (size, files.keys())
        assert "".join(files["index.html"]).strip() == "<html><body>hi</body></html>"
        assert "".join(files["style.css"]).strip() == "body{color:red}"
        assert [e[0] for e in ev].count("done") == 2


def test_truncated_output_is_closed():
    p = FileStreamParser()
    ev = p.feed("===FILE: index.html===\n<p>cut off")
    ev += p.finish()
    assert ev[-1][0] == "done" and ev[-1][1] == "index.html"


def test_size_limit():
    p = FileStreamParser(max_bytes=100)
    try:
        p.feed("===FILE: index.html===\n" + "x" * 500)
        assert False, "expected CodegenError"
    except CodegenError:
        pass


def test_filenames():
    assert sanitize_filename("index.html") == "index.html"
    assert sanitize_filename("js/app.js") == "js/app.js"
    for bad in ("../x.html", "/etc/passwd.txt", "a/../../b.html", "x.exe", "a\\b.html", "", ".hidden.html"):
        assert sanitize_filename(bad) is None, bad


def test_request_detection():
    yes = ["ek portfolio website banao", "build a landing page for my cafe", "html page bana do", "वेबसाइट बनाओ"]
    no = ["aaj mausam kaisa hai", "website kya hoti hai", "mujhe joke sunao"]
    for t in yes:
        assert looks_like_build_request(t), t
    for t in no:
        assert not looks_like_build_request(t), t


def test_strip_fences():
    assert strip_fences("```html\n<p>x</p>\n```") == "<p>x</p>\n"


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
