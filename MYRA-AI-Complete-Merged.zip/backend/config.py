"""Environment-driven settings. Everything is read once at import time."""
import os

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # dotenv is optional
    pass


def _chain(name: str, default: str) -> list[str]:
    return [p.strip().lower() for p in os.getenv(name, default).split(",") if p.strip()]


TOKEN = os.getenv("MYRA_TOKEN", "")

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY", "")

CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

CHAT_CHAIN = _chain("CHAT_CHAIN", "groq,claude,openai,gemini")
CODE_CHAIN = _chain("CODE_CHAIN", "claude,openai,gemini,groq")

FIRST_TOKEN_TIMEOUT = float(os.getenv("FIRST_TOKEN_TIMEOUT", "8"))
CODE_MAX_TOKENS = int(os.getenv("CODE_MAX_TOKENS", "6000"))
PROJECTS_DIR = os.getenv("PROJECTS_DIR", "projects")
PROJECT_TTL_DAYS = int(os.getenv("PROJECT_TTL_DAYS", "7"))

MAX_MESSAGE_CHARS = 8000
MAX_TASKS_PER_CONNECTION = 3
